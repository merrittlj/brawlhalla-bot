# brawlhalla-bot
A simple bot for Brawlhalla.